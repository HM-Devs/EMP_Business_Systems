/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.ac.city.acsf375.emp.services;

import java.util.List;
import uk.ac.city.acsf375.emp.domain.Client;
import uk.ac.city.acsf375.emp.domain.Department;
import uk.ac.city.acsf375.emp.domain.Employee;

/**
 *
 * @author Hamza
 */
public interface EmpManagementService {
     List<Department> findAllDepartments();
     List<Employee> findAllEmployees();
     List<Employee> addEmployee(Employee employee);
Employee findEmployeeByID(int id);
Client findClientByName(String name);
//Client findClientByName (String name);
}
