/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.ac.city.acsf375.emp.backingbeans;

import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import uk.ac.city.acsf375.emp.domain.Department;
import uk.ac.city.acsf375.emp.domain.Employee;
import uk.ac.city.acsf375.emp.services.EmpManagementService;

/**
 *
 * @author Hamzah
 */
@ManagedBean (name="addEmployeeBean")
public class AddEmployeeBean {
    
    @EJB
    private EmpManagementService service;
    private List<Employee> employees;
    private Employee employee;
    
    public String findId(int id){
        employee = service.findEmployeeByID(id);
        return "displayemployees";
    }
    public String addEmployee(Short employeeID, String name, String job, Short departmentID){
        
        Employee employee = new Employee();
        employee.setName(name);
        employee.setJob(job);
        employee.setEmployeeID(employeeID);
        Department department = new Department(departmentID);
        employee.setDepartmentID(department);
        employees = service.addEmployee(employee);
        return "allemployees";
    }

    public List<Employee> getEmployees() {
        return employees;
    }

    public void setEmployees(List<Employee> employees) {
        this.employees = employees;
    }
}