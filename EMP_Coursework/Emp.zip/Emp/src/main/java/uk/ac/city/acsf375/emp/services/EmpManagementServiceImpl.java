/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.ac.city.acsf375.emp.services;

import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import uk.ac.city.acsf375.emp.dataaccess.EmployeeDataManager;
import uk.ac.city.acsf375.emp.domain.Client;
import uk.ac.city.acsf375.emp.domain.Department;
import uk.ac.city.acsf375.emp.domain.Employee;

/**
 *
 * @author Hamza
 */
@Stateless
public class EmpManagementServiceImpl implements EmpManagementService {
   @EJB
    private EmployeeDataManager dao;
   
    @Override
    public List<Department> findAllDepartments() {
        return dao.allDepartments();
 
    }

    @Override
    public List<Employee> findAllEmployees() {
        return dao.allEmployees();
    }

    @Override
    public List<Employee> addEmployee(Employee employee) {
           dao.addEmployee(employee);
        return dao.allEmployees();
    }

    @Override
    public Employee findEmployeeByID(int id) {
        return dao.findEmployeeByID(id);
    }

    @Override
    public Client findClientByName(String name) {
        return dao.findClientByName(name);
    }

    
    


    
    

}
