/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.ac.city.acsf375.emp.backingbeans;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import uk.ac.city.acsf375.emp.domain.Client;
import uk.ac.city.acsf375.emp.services.EmpManagementService;

/**
 *
 * @author Hamza
 */
@ManagedBean (name="findClientBean")
public class FindClientBean {
    @EJB
    private EmpManagementService service;
    //private List<Client> clients;
    private Client client;
    
    public String findClientByName(String name){
        client = service.findClientByName(name);
        return "findclientnameresult";
}
   public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }
}
    
    