/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.ac.city.acsf375.emp.backingbeans;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import uk.ac.city.acsf375.emp.domain.Employee;
import uk.ac.city.acsf375.emp.services.EmpManagementService;

/**
 *
 * @author Hamza
 */
@ManagedBean (name="findEmployeeByIDBean")
public class FindEmployeeIdBean {
    @EJB
    private EmpManagementService service;
    private Employee employee;
    
    public String findByID(int id) {
        employee = service.findEmployeeByID(id);
        return "findemployeeresult";
    }
    public Employee getEmployee(){
        return employee;
    }
    public void setEmployee(Employee employee){
        this.employee = employee;
    }
}
