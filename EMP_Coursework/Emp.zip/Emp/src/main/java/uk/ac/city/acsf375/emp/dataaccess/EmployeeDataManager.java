/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.ac.city.acsf375.emp.dataaccess;

import java.util.List;
import uk.ac.city.acsf375.emp.domain.Client;
import uk.ac.city.acsf375.emp.domain.Department;
import uk.ac.city.acsf375.emp.domain.Employee;

/**
 *
 * @author Hamza
 */
public interface EmployeeDataManager {
    List<Department> allDepartments();
    List<Employee> allEmployees();
    Employee findEmployeeByID(int num);
    void addEmployee(Employee employee);
    Client findClientByName(String name);
}

